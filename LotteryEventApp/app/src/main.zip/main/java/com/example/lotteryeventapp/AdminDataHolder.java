package com.example.lotteryeventapp;

public class AdminDataHolder {
    public AdminDataHolder() {
        throw new UnsupportedOperationException("Not implemented yet");
    }
}
