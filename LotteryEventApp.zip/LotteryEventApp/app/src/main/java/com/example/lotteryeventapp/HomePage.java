package com.example.lotteryeventapp;

public class HomePage {
}
